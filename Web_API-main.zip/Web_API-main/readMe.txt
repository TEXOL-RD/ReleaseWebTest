Merger HTML and golang API 
